-- MySQL dump 10.13  Distrib 5.7.12, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: db_coursework
-- ------------------------------------------------------
-- Server version	5.6.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `k`
--

DROP TABLE IF EXISTS `k`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k` (
  `S_No` char(3) NOT NULL,
  `S_name` varchar(50) CHARACTER SET utf8 NOT NULL,
  `transfer` int(11) NOT NULL,
  `attraction` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`S_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k`
--

LOCK TABLES `k` WRITE;
/*!40000 ALTER TABLE `k` DISABLE KEYS */;
INSERT INTO `k` VALUES ('K03','东湖渠',0,NULL),('K08','东风北桥',0,NULL),('K12','九龙山',1,NULL),('K19','北京南站',1,NULL),('K13','北工大西门',0,NULL),('K14','十里河',1,NULL),('K01','善各庄',0,NULL),('K11','大望路',1,NULL),('K07','将台',0,NULL),('K15','方庄',0,NULL),('K17','景泰',0,NULL),('K04','望京',1,NULL),('K06','望京南',0,'798艺术街区'),('K02','来广营',0,NULL),('K09','枣营',0,NULL),('K18','永定门外',0,NULL),('K16','蒲黄榆',1,NULL),('K10','金台路',1,NULL),('K05','阜通',0,NULL);
/*!40000 ALTER TABLE `k` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-12-07 10:23:09

-- MySQL dump 10.13  Distrib 5.7.12, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: db_coursework
-- ------------------------------------------------------
-- Server version	5.6.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `q`
--

DROP TABLE IF EXISTS `q`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `q` (
  `T_name` varchar(50) CHARACTER SET utf8 NOT NULL,
  `T_line1` char(3) NOT NULL,
  `T_line2` char(3) NOT NULL,
  PRIMARY KEY (`T_name`,`T_line1`,`T_line2`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `q`
--

LOCK TABLES `q` WRITE;
/*!40000 ALTER TABLE `q` DISABLE KEYS */;
INSERT INTO `q` VALUES ('七里庄','H08','K06'),('七里庄','K06','H08'),('三元桥','I14','Q02'),('三元桥','Q02','I14'),('东单','A17','D18'),('东单','D18','A17'),('东直门','B06','J16'),('东直门','B06','O01'),('东直门','J16','B06'),('东直门 ','J16','O01'),('东直门','O01','B06'),('东直门','O01','J16'),('九龙山','F13','K12'),('九龙山','K12','F13'),('公主坟','A08','I40'),('公主坟','I40','A08'),('六里桥','H07','I38'),('六里桥','I38','H07'),('军事博物馆','A09','H04'),('军事博物馆','H04','A09'),('北京南站','C21','K19'),('北京南站','K19','C21'),('北京西站','F01','H05'),('北京西站','H05','F01'),('北土城','G13','I09'),('北土城','I09','G13'),('十里河','I24','K14'),('十里河','K14','I24'),('南锣鼓巷','E09','G18'),('南锣鼓巷','G18','E09'),('双井','F12','I21'),('双井','I21','F12'),('呼家楼','E13','I18'),('呼家楼','I18','E13'),('国家图书馆','C10','H01'),('国家图书馆','H01','C10'),('国贸','A19','I20'),('国贸','I20','A19'),('复兴门','A12','B16'),('复兴门','B16','A12'),('大屯路东','D07','L15'),('大屯路东','L15','D07'),('大望路','A21','K11'),('大望路','K11','A21'),('奥林匹克公园','G11','L17'),('奥林匹克公园','L17','G11'),('宋家庄','D24','I27'),('宋家庄','I27','D24'),('宋家庄','I27','P01'),('宋家庄','P01','D22'),('宣武门','B14','C18'),('宣武门','C18','B14'),('崇文门','B11','D17'),('崇文门','D17','B11'),('平安里','C14','E07'),('平安里','E07','C14'),('建国门','A18','B09'),('建国门','B09','A18'),('惠新西街南口','D09','I11'),('惠新西街南口','I11','D09'),('慈寿寺','E02','I42'),('慈寿寺','I42','E02'),('望京','K04','L12'),('望京','L12','K04'),('望京西','J12','L13'),('望京西','L13','J12'),('朝阳门','B08','E11'),('朝阳门','E11','B08'),('朱辛庄','G01','M10'),('朱辛庄','M10','G01'),('海淀黄庄','C07','I03'),('海淀黄庄','I03','C07'),('白石桥南','E04','H02'),('白石桥南','H02','E04'),('知春路','I05','J03'),('知春路','J03','I05'),('磁器口','D20','F09'),('磁器口','F09','D20'),('立水桥','D04','J10'),('立水桥','J10','D04'),('芍药居','I12','J13'),('芍药居','J13','I12'),('菜市口','C19','F05'),('菜市口','F05','C19'),('蒲黄榆','D22','K16'),('蒲黄榆','K16','D22'),('西二旗','J06','N12'),('西二旗','N12','J06'),('西单','A13','C17'),('西单','C17','A13'),('西局','I37','K07'),('西局','K07','I37'),('西直门','B01','C12'),('西直门','B01','J01'),('西直门','C12','B01'),('西直门','C12','J01'),('西直门','J01','B01'),('西直门','J01','C12'),('角门东','C23','I31'),('角门东','I31','C23'),('车公庄','B18','E06'),('车公庄','E06','B18'),('郭公庄','H13','N01'),('郭公庄','N01','H13'),('金台路','E14','K10'),('金台路','K10','E14'),('雍和宫','B05','D12'),('雍和宫','D12','B05'),('霍营','G05','J09'),('霍营','J09','G05'),('鼓楼大街','B03','G16'),('鼓楼大街','G16','B03');
/*!40000 ALTER TABLE `q` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-12-07 10:23:10

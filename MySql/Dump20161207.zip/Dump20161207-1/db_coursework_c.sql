-- MySQL dump 10.13  Distrib 5.7.12, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: db_coursework
-- ------------------------------------------------------
-- Server version	5.6.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `c`
--

DROP TABLE IF EXISTS `c`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `c` (
  `S_No` char(3) NOT NULL,
  `S_name` varchar(50) CHARACTER SET utf8 NOT NULL,
  `transfer` int(11) NOT NULL,
  `attraction` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`S_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `c`
--

LOCK TABLES `c` WRITE;
/*!40000 ALTER TABLE `c` DISABLE KEYS */;
INSERT INTO `c` VALUES ('C06','中关村',0,NULL),('C33','义和庄',0,NULL),('C08','人民大学',0,NULL),('C24','公益西桥',0,NULL),('C11','动物园',0,'动物园'),('C21','北京南站',1,NULL),('C05','北京大学东门',0,NULL),('C02','北宫门',0,'颐和园'),('C10','国家图书馆',1,'国家图书馆'),('C04','圆明园',0,'圆明园'),('C35','天宫院',0,NULL),('C01','安河桥北',0,NULL),('C18','宣武门',1,NULL),('C14','平安里',1,NULL),('C25','新宫',0,NULL),('C13','新街口',0,NULL),('C29','枣园',0,NULL),('C07','海淀黄庄',1,NULL),('C30','清源路',0,NULL),('C16','灵境胡同',0,NULL),('C34','生物医药基地',0,NULL),('C19','菜市口',1,NULL),('C17','西单',1,NULL),('C15','西四',0,NULL),('C12','西直门',1,NULL),('C26','西红门',0,NULL),('C03','西苑',0,NULL),('C23','角门西',1,NULL),('C20','陶然亭',0,NULL),('C22','马家堡',0,NULL),('C27','高米店北',0,NULL),('C28','高米店南',0,NULL),('C09','魏公村',0,NULL),('C32','黄村火车站',0,NULL),('C31','黄村西大街',0,NULL);
/*!40000 ALTER TABLE `c` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-12-07 10:23:08

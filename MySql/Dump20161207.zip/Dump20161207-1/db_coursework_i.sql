-- MySQL dump 10.13  Distrib 5.7.12, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: db_coursework
-- ------------------------------------------------------
-- Server version	5.6.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `i`
--

DROP TABLE IF EXISTS `i`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `i` (
  `S_No` char(3) NOT NULL,
  `S_name` varchar(50) CHARACTER SET utf8 NOT NULL,
  `transfer` int(11) NOT NULL,
  `attraction` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`S_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `i`
--

LOCK TABLES `i` WRITE;
/*!40000 ALTER TABLE `i` DISABLE KEYS */;
INSERT INTO `i` VALUES ('I14','三元桥',1,NULL),('I35','丰台站',0,NULL),('I15','亮马桥',0,NULL),('I08','健德门',0,NULL),('I40','公主坟',1,'中央电视台'),('I38','六里桥',1,NULL),('I16','农业展览馆',0,NULL),('I25','分钟寺',0,NULL),('I22','劲松',0,NULL),('I09','北土城',1,NULL),('I24','十里河',1,NULL),('I21','双井',0,NULL),('I18','呼家楼',1,NULL),('I17','团结湖',0,NULL),('I20','国贸',1,NULL),('I29','大红门',0,NULL),('I13','太阳宫',0,NULL),('I10','安贞门',0,NULL),('I27','宋家庄',1,NULL),('I01','巴沟',0,NULL),('I11','惠新西街南口',1,NULL),('I42','慈寿寺',1,NULL),('I26','成寿寺',0,NULL),('I36','泥洼',0,NULL),('I03','海淀黄庄',1,NULL),('I23','潘家园',0,'潘家园'),('I45','火器营',0,NULL),('I07','牡丹园',0,NULL),('I05','知春路',1,NULL),('I04','知春里',0,NULL),('I28','石榴庄',0,NULL),('I33','纪家庙',0,NULL),('I12','芍药居',1,NULL),('I02','苏州街',0,NULL),('I32','草桥',0,NULL),('I39','莲花桥',0,NULL),('I06','西土城',0,NULL),('I37','西局',1,NULL),('I41','西钓鱼台',0,NULL),('I30','角门东',0,NULL),('I31','角门西',1,NULL),('I43','车道沟',0,NULL),('I19','金台夕照',0,'世贸天阶'),('I44','长春桥',0,NULL),('I34','首经贸',0,NULL);
/*!40000 ALTER TABLE `i` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-12-07 10:23:09

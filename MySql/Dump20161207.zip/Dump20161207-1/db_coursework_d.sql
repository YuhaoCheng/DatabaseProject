-- MySQL dump 10.13  Distrib 5.7.12, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: db_coursework
-- ------------------------------------------------------
-- Server version	5.6.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `d`
--

DROP TABLE IF EXISTS `d`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `d` (
  `S_No` char(3) NOT NULL,
  `S_name` varchar(50) CHARACTER SET utf8 NOT NULL,
  `transfer` int(11) NOT NULL,
  `attraction` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`S_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `d`
--

LOCK TABLES `d` WRITE;
/*!40000 ALTER TABLE `d` DISABLE KEYS */;
INSERT INTO `d` VALUES ('D18','东单',1,NULL),('D16','东四',1,NULL),('D23','刘家窑',0,NULL),('D14','北新桥',0,NULL),('D06','北苑路北',0,NULL),('D10','和平西桥',0,NULL),('D11','和平里北街',0,NULL),('D07','大屯路东',1,NULL),('D21','天坛东门',0,'天坛'),('D02','天通苑',0,NULL),('D01','天通苑北',0,'北邮宏福校区'),('D03','天通苑南',0,NULL),('D24','宋家庄',1,NULL),('D19','崇文门',1,NULL),('D15','张自忠路',0,NULL),('D08','惠新西街北口',0,NULL),('D09','惠新西街南口',1,NULL),('D13','新街口',0,NULL),('D17','灯市口',0,NULL),('D20','磁器口',1,NULL),('D04','立水桥',1,NULL),('D05','立水桥南',0,NULL),('D22','蒲黄榆',1,NULL),('D12','雍和宫',1,'雍和宫');
/*!40000 ALTER TABLE `d` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-12-07 10:23:08
